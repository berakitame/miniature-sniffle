import fs from "node:fs";
import path from "node:path";

export class TelemetryAnalyzer {
  constructor({ logPath = "telemetry.jsonl", interval = 60_000, ollamaUrl = "", ollamaModel = "" } = {}) {
    this.logPath = path.resolve(logPath);
    this.interval = Math.max(5_000, Number(interval));
    this.ollamaUrl = String(ollamaUrl).replace(/\/$/, "");
    this.ollamaModel = String(ollamaModel);
    this.history = [];
    this.lastAnalysis = "Waiting for mining telemetry.";
    this.lastAnalysisAt = 0;
    this.loadHistory();
  }

  loadHistory() {
    try {
      const lines = fs.readFileSync(this.logPath, "utf8").trim().split(/\r?\n/).filter(Boolean).slice(-120);
      this.history = lines.map((line) => JSON.parse(line));
    } catch {
      this.history = [];
    }
  }

  async record(state) {
    const snapshot = {
      timestamp: Date.now() / 1000,
      status: String(state.status ?? "unknown"),
      job: String(state.job ?? "-").slice(0, 128),
      shares: Math.max(0, Number.parseInt(state.shares ?? 0, 10) || 0),
      hashrate: Math.max(0, Number(state.hashrate) || 0),
    };
    this.history.push(snapshot);
    this.history = this.history.slice(-120);
    fs.mkdirSync(path.dirname(this.logPath), { recursive: true });
    fs.appendFileSync(this.logPath, `${JSON.stringify(snapshot)}\n`, "utf8");
    const now = Date.now();
    if (now - this.lastAnalysisAt >= this.interval) {
      this.lastAnalysis = await this.analyze();
      this.lastAnalysisAt = now;
    }
    return snapshot;
  }

  metrics() {
    if (!this.history.length) return { samples: 0, hashrate: 0, trend_pct: 0, shares: 0 };
    const rates = this.history.map((item) => item.hashrate).filter((rate) => rate > 0);
    const midpoint = Math.max(1, Math.floor(rates.length / 2));
    const average = (items) => items.length ? items.reduce((a, b) => a + b, 0) / items.length : 0;
    const oldRate = average(rates.slice(0, midpoint));
    const newRate = average(rates.slice(midpoint).length ? rates.slice(midpoint) : rates.slice(0, midpoint));
    const latest = this.history.at(-1);
    return {
      samples: this.history.length,
      hashrate: Number(latest.hashrate.toFixed(2)),
      average_hashrate: Number(average(rates).toFixed(2)),
      trend_pct: Number((oldRate ? ((newRate - oldRate) / oldRate) * 100 : 0).toFixed(2)),
      shares: latest.shares,
      status: latest.status,
    };
  }

  ruleAnalysis(metrics) {
    if (!metrics.samples) return "Waiting for mining telemetry.";
    if (metrics.hashrate <= 0) return "Mining is not producing hashrate; check the pool connection and worker state.";
    if (metrics.trend_pct <= -15) return `Hashrate is falling (${metrics.trend_pct.toFixed(1)}% trend); check CPU contention and thermal throttling.`;
    if (metrics.trend_pct >= 15) return `Hashrate is improving (${metrics.trend_pct.toFixed(1)}% trend); keep the current configuration while collecting more samples.`;
    return `Mining is stable at ${metrics.hashrate.toFixed(2)} H/s with ${metrics.shares} submitted shares.`;
  }

  async analyze() {
    const metrics = this.metrics();
    if (this.ollamaUrl && this.ollamaModel) {
      try {
        const response = await fetch(`${this.ollamaUrl}/api/generate`, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({
            model: this.ollamaModel,
            stream: false,
            prompt: `You analyze explicitly labeled cryptocurrency-mining telemetry. Give one concise operational observation. Never claim this is LLM inference. Metrics: ${JSON.stringify(metrics)}`,
          }),
          signal: AbortSignal.timeout(10_000),
        });
        if (response.ok) {
          const body = await response.json();
          const text = String(body.response ?? "").trim().slice(0, 500);
          if (text) return text;
        }
      } catch {
        // Fall back to deterministic analysis when the local model is unavailable.
      }
    }
    return this.ruleAnalysis(metrics);
  }
}
