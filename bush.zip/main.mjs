#!/usr/bin/env node
import { spawn } from "node:child_process";
import http from "node:http";
import path from "node:path";
import readline from "node:readline";
import { fileURLToPath } from "node:url";
import { TelemetryAnalyzer } from "./telemetry.mjs";

const base = path.dirname(fileURLToPath(import.meta.url));
const analyzer = new TelemetryAnalyzer({
  logPath: path.join(base, "telemetry.jsonl"),
  interval: Number(process.env.ANALYSIS_INTERVAL || 60) * 1000,
  ollamaUrl: process.env.OLLAMA_URL || "",
  ollamaModel: process.env.OLLAMA_MODEL || "",
});
const state = { status: "starting", job: "-", shares: 0, hashrate: 0 };
let bridgeStatus = "not_started";
let bridge = null;
let stopping = false;

function printStatus() {
  process.stdout.write(`\rMINING • Status: ${state.status} • Job: ${state.job} • Hashrate: ${state.hashrate.toFixed(2)} H/s • Shares: ${state.shares}     `);
}

function startBridge() {
  const python = process.env.PYTHON || "python3";
  bridge = spawn(python, [path.join(base, "miner_bridge.py")], {
    cwd: base,
    env: process.env,
    stdio: ["ignore", "pipe", "pipe"],
  });
  bridgeStatus = "starting";
  const lines = readline.createInterface({ input: bridge.stdout });
  lines.on("line", async (line) => {
    let event;
    try { event = JSON.parse(line); }
    catch { console.error(`\nInvalid bridge output: ${line.slice(0, 200)}`); return; }
    if (event.type === "telemetry") {
      state.status = String(event.status ?? state.status);
      state.job = String(event.job ?? state.job);
      state.shares = Math.max(0, Number(event.shares) || 0);
      state.hashrate = Math.max(0, Number(event.hashrate) || 0);
      await analyzer.record(state);
      printStatus();
    } else if (event.type === "bridge") {
      bridgeStatus = String(event.status);
    } else if (event.type === "fatal") {
      bridgeStatus = "failed";
      console.error(`\nBridge error: ${event.message}`);
    }
  });
  bridge.stderr.on("data", (chunk) => process.stderr.write(`\n[bridge] ${chunk}`));
  bridge.on("error", (error) => {
    bridgeStatus = "failed";
    console.error(`\nCould not start ${python}: ${error.message}`);
  });
  bridge.on("exit", (code, signal) => {
    bridgeStatus = stopping ? "stopped" : "exited";
    if (!stopping) console.error(`\nMining bridge exited (code=${code}, signal=${signal ?? "none"}).`);
  });
}

const page = `<!doctype html><meta charset="utf-8"><title>Node Mining Telemetry</title>
<style>body{font:16px system-ui;max-width:800px;margin:40px auto;background:#111;color:#eee}pre{background:#222;padding:20px;border-radius:8px}h1{color:#7dd3fc}</style>
<h1>Cryptocurrency Mining Telemetry</h1><p>Linux miner controlled by Node.js through a Python native-module bridge. Optional local-LLM analysis is clearly labeled.</p><pre id="x">Loading...</pre>
<script>async function f(){let r=await fetch('/api/telemetry');x.textContent=JSON.stringify(await r.json(),null,2)}f();setInterval(f,5000)</script>`;

const server = http.createServer((request, response) => {
  if (request.url === "/api/telemetry") {
    const body = JSON.stringify({ workload: "cryptocurrency-mining", bridge_status: bridgeStatus, metrics: analyzer.metrics(), analysis: analyzer.lastAnalysis });
    response.writeHead(200, { "content-type": "application/json", "content-length": Buffer.byteLength(body) });
    response.end(body);
    return;
  }
  response.writeHead(200, { "content-type": "text/html; charset=utf-8", "content-length": Buffer.byteLength(page) });
  response.end(page);
});

const host = "127.0.0.1";
const port = Number(process.env.DASHBOARD_PORT || 8765);
server.listen(port, host, () => {
  console.log(`Mining telemetry dashboard: http://${host}:${port}`);
  startBridge();
});

function shutdown() {
  if (stopping) return;
  stopping = true;
  bridgeStatus = "stopping";
  if (bridge && !bridge.killed) bridge.kill("SIGTERM");
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(1), 5_000).unref();
}
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
