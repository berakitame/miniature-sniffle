"""Honest local telemetry dashboard for the existing Python miner.

Run: python dashboard.py
Open: http://127.0.0.1:8765

This dashboard identifies the workload as cryptocurrency mining and does not
rename, conceal, or spoof the miner process.
"""

from __future__ import annotations

import json
import os
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from telemetry import TelemetryAnalyzer

analyzer = TelemetryAnalyzer(
    log_path=Path(__file__).with_name("telemetry.jsonl"),
    interval=float(os.getenv("ANALYSIS_INTERVAL", "60")),
    ollama_url=os.getenv("OLLAMA_URL"),
    ollama_model=os.getenv("OLLAMA_MODEL"),
)

# Demo/health state. main.py can call update_state() from its report callback.
state = {"status": "dashboard_only", "job": "-", "shares": 0, "hashrate": 0.0}


def update_state(new_state: dict) -> None:
    state.update(new_state)
    analyzer.record(state)


class Handler(BaseHTTPRequestHandler):
    def do_GET(self) -> None:  # noqa: N802
        if self.path == "/api/telemetry":
            payload = {"workload": "cryptocurrency-mining", "metrics": analyzer.metrics(), "analysis": analyzer.last_analysis}
            body = json.dumps(payload).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        html = """<!doctype html><meta charset=utf-8><title>Mining Telemetry + Local LLM Analysis</title>
<style>body{font:16px system-ui;max-width:800px;margin:40px auto;background:#111;color:#eee}pre{background:#222;padding:20px;border-radius:8px}h1{color:#7dd3fc}</style>
<h1>Cryptocurrency Mining Telemetry</h1><p>This workload is explicitly labeled. Local LLM analysis is optional.</p><pre id=x>Loading...</pre>
<script>async function f(){let r=await fetch('/api/telemetry');document.querySelector('#x').textContent=JSON.stringify(await r.json(),null,2)}f();setInterval(f,5000)</script>"""
        body = html.encode()
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *_args) -> None:
        return


if __name__ == "__main__":
    host, port = "127.0.0.1", int(os.getenv("DASHBOARD_PORT", "8765"))
    print(f"Honest mining telemetry dashboard: http://{host}:{port}")
    print("Optional local LLM: set OLLAMA_URL=http://127.0.0.1:11434 and OLLAMA_MODEL=...\n")
    server = ThreadingHTTPServer((host, port), Handler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        server.shutdown()
