import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import test from "node:test";
import { TelemetryAnalyzer } from "./telemetry.mjs";

test("records sanitized mining metrics", async () => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), "miner-telemetry-"));
  const logPath = path.join(directory, "telemetry.jsonl");
  const analyzer = new TelemetryAnalyzer({ logPath, interval: 5_000 });
  await analyzer.record({ status: "hashrate", job: "a", shares: 2, hashrate: 100, password: "secret" });
  await analyzer.record({ status: "hashrate", job: "b", shares: 3, hashrate: 110, url: "private" });
  assert.deepEqual(analyzer.metrics(), {
    samples: 2,
    hashrate: 110,
    average_hashrate: 105,
    trend_pct: 10,
    shares: 3,
    status: "hashrate",
  });
  const text = fs.readFileSync(logPath, "utf8");
  assert.equal(text.includes("secret"), false);
  assert.equal(text.includes("private"), false);
  fs.rmSync(directory, { recursive: true, force: true });
});

test("reports zero hashrate", async () => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), "miner-telemetry-"));
  const analyzer = new TelemetryAnalyzer({ logPath: path.join(directory, "telemetry.jsonl") });
  await analyzer.record({ status: "connected", shares: 0, hashrate: 0 });
  assert.match(await analyzer.analyze(), /not producing hashrate/);
  fs.rmSync(directory, { recursive: true, force: true });
});
