#!/usr/bin/env python3
"""Thin Linux bridge between the Python-only native miner and Node.js.

Stdout is reserved for newline-delimited JSON events. Pool credentials are read
from the existing .env file and are never emitted.
"""

from __future__ import annotations

import json
import os
import signal
import sys
import time
from pathlib import Path


def emit(event: dict) -> None:
    print(json.dumps(event, separators=(",", ":")), flush=True)


def load_env(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.exists():
        return values
    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip()
    return values


def validate(values: dict[str, str]) -> tuple[str, str, str, str, int]:
    required = ("REDIS_URL", "REDIS_PAIR", "REDIS_USER", "REDIS_PASS")
    missing = [key for key in required if not values.get(key)]
    if missing:
        raise ValueError("Missing required configuration: " + ", ".join(missing))
    try:
        threads = int(values.get("REDIS_PIPE", "2"))
    except ValueError as error:
        raise ValueError("REDIS_PIPE must be an integer") from error
    if not 1 <= threads <= 256:
        raise ValueError("REDIS_PIPE must be between 1 and 256")
    return (
        values["REDIS_URL"].rstrip("/") + "/" + values["REDIS_PAIR"].lstrip("/"),
        values["REDIS_USER"],
        values["REDIS_PASS"],
        values["REDIS_PAIR"],
        threads,
    )


def main() -> int:
    base = Path(__file__).resolve().parent
    values = load_env(base / ".env")
    try:
        url, user, password, _pair, threads = validate(values)
    except ValueError as error:
        emit({"type": "fatal", "message": str(error)})
        return 2

    # Ensure the local Linux extension takes precedence over similarly named packages.
    sys.path.insert(0, str(base))
    try:
        import redis as native_miner  # type: ignore
    except Exception as error:
        emit({
            "type": "fatal",
            "message": f"Cannot load Linux native miner: {type(error).__name__}: {error}",
        })
        return 3

    state = {"status": "starting", "job": "-", "shares": 0, "hashrate": 0.0}

    def report(status, job, shares, hashrate, message):
        state["status"] = str(status)
        if status == "job_received":
            state["job"] = str(job)[:128]
        if status == "share_found":
            state["shares"] = max(0, int(shares))
        if status == "hashrate":
            state["hashrate"] = max(0.0, float(hashrate))
        emit({"type": "telemetry", **state, "message": str(message)[:300]})

    try:
        connection = native_miner.connect(
            url=url,
            user=user,
            password=password,
            threads=threads,
            on_report=report,
            light=False,
            debug_all=False,
        )
    except Exception as error:
        emit({"type": "fatal", "message": f"Miner startup failed: {type(error).__name__}: {error}"})
        return 4

    stopping = False

    def stop(_signum, _frame):
        nonlocal stopping
        stopping = True

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    emit({"type": "bridge", "status": "running", "threads": threads})
    while not stopping and connection.is_running():
        time.sleep(0.5)
    emit({"type": "bridge", "status": "stopped"})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
